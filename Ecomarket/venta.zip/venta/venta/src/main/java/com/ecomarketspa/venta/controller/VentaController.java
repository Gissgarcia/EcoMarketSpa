package com.ecomarketspa.venta.controller;
import com.ecomarketspa.venta.model.VentaModel;
import com.ecomarketspa.venta.service.VentaService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ventas")
public class VentaController {

    @Autowired
    private VentaService ventaService;

    @Operation(summary = "Listar todas las ventas")
    @ApiResponse(responseCode = "200", description = "Listado exitoso de ventas")
    @GetMapping
    public List<VentaModel> getAllVentas() {
        return ventaService.getAllVentas();
    }

    @Operation(summary = "Obtener venta por ID")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Venta encontrada"),
            @ApiResponse(responseCode = "404", description = "Venta no encontrada")
    })
    @GetMapping("/{id}")
    public ResponseEntity<VentaModel> getVentaById(
            @Parameter(description = "ID de la venta") @PathVariable Integer id) {
        Optional<VentaModel> venta = ventaService.getVentasById(id);
        return venta.map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @Operation(summary = "Crear una nueva venta")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "201", description = "Venta creada exitosamente"),
            @ApiResponse(responseCode = "400", description = "Datos inválidos para crear la venta")
    })
    @PostMapping
    public ResponseEntity<VentaModel> createVenta(
            @Valid @org.springframework.web.bind.annotation.RequestBody VentaModel venta) {
        VentaModel nueva = ventaService.createVentas(venta);
        return ResponseEntity.status(201).body(nueva);
    }

    @Operation(summary = "Actualizar una venta")
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Venta actualizada correctamente"),
            @ApiResponse(responseCode = "404", description = "Venta no encontrada")
    })
    @PutMapping("/{id}")
    public ResponseEntity<VentaModel> updateVenta(
            @PathVariable Integer id,
            @org.springframework.web.bind.annotation.RequestBody VentaModel venta) {
        try {
            venta.setId(id);
            VentaModel actualizada = ventaService.updateVentas(id, venta);
            return ResponseEntity.ok(actualizada);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @Operation(summary = "Eliminar una venta")
    @ApiResponse(responseCode = "204", description = "Venta eliminada correctamente")
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteVenta(@PathVariable Integer id) {
        ventaService.deleteVentas(id);
        return ResponseEntity.noContent().build();
    }
}